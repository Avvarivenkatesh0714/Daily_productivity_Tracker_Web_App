from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_mail import Mail
from config import Config

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
mail = Mail()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    mail.init_app(app)
    Migrate(app, db)

    login_manager.login_view = "auth.login"

    with app.app_context():
        from models import User  # Import models inside app context
        db.create_all()  # Ensure tables are created

    # Register blueprints
    from routes import auth_bp
    app.register_blueprint(auth_bp)

    return app

app = create_app()
